from django.shortcuts import render
from django.http import HttpResponse
from .models import UserProfile

def index(request):
    return render(request,'index.html')
def Rcboattech(request):
    return render(request,'Rcboattech.html')
def rcboattech_view(request):
    return render(request,'Rcboattech.html')
def index_view(request):
    return render(request, 'index.html')
def index2_view(request):
    return render(request, 'index2.html')
from .models import UserProfile
def report(request):
    return render(request, 'report.html')



from django.shortcuts import render
from django.contrib import messages
from .models import UserProfile

def registration(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        c_password = request.POST.get('c_password')
        
        if not username or not email or not password or not c_password:
            message = 'Please fill out all required fields.'
            return render(request, 'register.html', {'message': message})
        if UserProfile.objects.filter(email=email).exists():
            message = 'Email already exists. Please use a different email.'
            
            return render(request, 'register.html', {'message': message})
        if password != c_password:
            message = 'Password and Confirm Password do not match.'
            return render(request, 'register.html', {'message': message})
        UserProfile(username=username, email=email, password=password, c_password=c_password).save()
        return render(request, 'profile.html')
    else:
        return render(request, 'register.html')


from django.shortcuts import render
from django.contrib import messages
from .models import UserProfile
from .forms import ProfileForm

def logins(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        if not email or not password:
            messages ='Please provide both email and password.'
            return render(request, 'login.html',{'message1':messages})
        
        user = UserProfile.objects.filter(email=email, password=password).first()
        if user:
            context = {
                'username': user.username,
            }
            return render(request, 'index2.html',context)
        else:
            messages ='Invalid email or password.'
            return render(request, 'login.html',{'message1':messages})
    else:
        return render(request, 'login.html')


  
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Profile
from .forms import ProfileForm 

def profile(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        surname = request.POST.get('surname')
        gender = request.POST.get('gender')
        mobile_number = request.POST.get('mobile_number')
        district = request.POST.get('district')
        state = request.POST.get('state')
        address = request.POST.get('address')
        
        form = ProfileForm(request.POST)
        if form.is_valid():
            form.save()
            context={
            'first_name':first_name,'surname':surname,'gender':gender,'mobile_number':mobile_number,'district':district,'state':state,'address':address
            }
            return render(request,'profile_view.html',context)  
        else:
            messages ='Input details error.'
            return render(request,'profile.html',{'messages':messages})
    else:
        form = ProfileForm()
    return render(request, 'profile.html', {'form': form})

            
def profile_view(request):
        msg ="Registration & Profile updated successfully. You can now login."
        return render(request, 'login.html',{'msg':msg})
    

from django.shortcuts import render
from .models import Staff

def Authorityreg(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        sid = request.POST.get('sid')
        code = request.POST.get('code')
        new_password = request.POST.get('new_password')
        
        if not name or not sid or not code or not new_password:
            message = 'Please fill out all required fields.'
            return render(request, 'Authorityreg.html', {'msgs1': message})
        if Staff.objects.filter(sid=sid).exists():
            message = 'ID already exists. Please use a different ID.'
            return render(request, 'Authorityreg.html', {'msgs1': message})
        if code != "1234":
            message = 'Invalid company code.'
            return render(request, 'Authorityreg.html', {'msgs1': message})
        Staff(sid=sid,code=code, new_password=new_password,name=name).save()
        message = 'staff Reg successfull. now you can login'
        return render(request, 'Authoritylogin.html', {'msgs2': message})
    else:
        return render(request, 'Authorityreg.html')
    

def Authoritylogin(request):
    if request.method == 'POST':
        sid = request.POST.get('sid')
        new_password = request.POST.get('new_password')
        if not sid or not new_password:
            messages ='Please provide both Id and password.'
            return render(request, 'Authoritylogin.html',{'msgs3':messages})
        
        staff = Staff.objects.filter(sid=sid, new_password=new_password).first()
        if staff:
            context = {
                'name':staff.name,
            }
            return render(request, 'Authoritystatus.html',context)
        else:
            messages ='Invalid Id or password.'
            return render(request, 'Authoritylogin.html',{'msgs3':messages})
    else:
        return render(request, 'Authoritylogin.html')
