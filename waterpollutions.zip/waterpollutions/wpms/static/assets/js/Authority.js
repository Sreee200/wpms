document.addEventListener("DOMContentLoaded", function () {
  var authorityRadios = document.querySelectorAll('input[name="authority"]');
  var navbarText = document.getElementById('navbarText');

  authorityRadios.forEach(function (radio) {
    radio.addEventListener('change', function () {
      switch (this.value) {
        case 'municipality':
          navbarText.textContent = 'Municipality';
          break;
        case 'corporation':
          navbarText.textContent = 'Corporation';
          break;
        case 'panchayat':
          navbarText.textContent = 'Panchayat';
          break;
      }
    });
  });
});
