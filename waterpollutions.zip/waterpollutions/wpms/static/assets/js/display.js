  // JavaScript to show/hide the help desk pop-up
  document.getElementById('helpDeskLink').addEventListener('click', function() {
    document.getElementById('helpDeskPopup').style.display = 'block';
  });

  document.getElementById('closeHelpDesk').addEventListener('click', function() {
    document.getElementById('helpDeskPopup').style.display = 'none';
  });

  // Close the pop-up if clicked outside of it
  window.addEventListener('click', function(event) {
    if (event.target == document.getElementById('helpDeskPopup')) {
      document.getElementById('helpDeskPopup').style.display = 'none';
    }
  });