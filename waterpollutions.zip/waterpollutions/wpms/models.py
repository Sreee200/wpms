from django.db import models
from django.core.validators import MinLengthValidator 

class UserProfile(models.Model):
    username = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=15, validators=[MinLengthValidator(8)])
    c_password = models.CharField(max_length=15, validators=[MinLengthValidator(8)])
    
class Profile(models.Model):
    first_name = models.CharField(max_length=100)
    surname = models.CharField(max_length=100)
    gender = models.CharField(max_length=10, choices=(('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')))
    mobile_number = models.CharField(max_length=15)
    district = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    address = models.TextField()
    
class Staff(models.Model):
    name = models.CharField(max_length=100)
    sid = models.CharField(max_length=5)
    code = models.CharField(max_length=5)
    new_password = models.CharField(max_length=15, validators=[MinLengthValidator(8)])
