from django.contrib import admin
from .models import UserProfile
from .models import Staff
from .models import Profile

admin.site.register(UserProfile)
admin.site.register(Staff)
admin.site.register(Profile)


