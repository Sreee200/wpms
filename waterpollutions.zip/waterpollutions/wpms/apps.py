from django.apps import AppConfig


class WpmsConfig(AppConfig):
    name = 'wpms'
