from django.urls import path,include
from . import views
from . views import rcboattech_view
from . views import index_view
from .views import registration
from .views import index2_view
from .views import logins
from .views import profile
from .views import report
from .views import Authoritylogin
from .views import Authorityreg
from .views import profile_view
urlpatterns = [
    
    path('', views.index),
    path('Authoritylogin', Authoritylogin,name='Authoritylogin'),
    path('Authorityreg', Authorityreg,name='Authorityreg'),
    path('Rcboattech.html', views.rcboattech_view, name='rcboattech'),
    path('index', views.index_view, name='index'),
    path('register', registration, name='registration'),
    path('index2',views.index2_view, name='index2'),
    path('logins', views.logins, name='logins'),
    path('profile',profile,name='profile'),
    path('report',report,name='report'),
    path('profile_view',profile_view,name='profile_view'),
]
